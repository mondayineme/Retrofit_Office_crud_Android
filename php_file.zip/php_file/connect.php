<?php 

$conn = mysqli_connect("localhost", "id12206515_smartdev", "BEST49@m", "id12206515_todos");

?>